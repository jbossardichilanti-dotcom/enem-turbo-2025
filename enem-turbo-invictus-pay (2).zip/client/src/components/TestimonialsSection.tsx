import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Star } from "lucide-react";

const testimonials = [
  {
    name: "Maria Silva",
    initials: "MS",
    text: "Estou me preparando com o ENEM Turbo e já sinto muita diferença! Os packs são super organizados e me ajudam a estudar tudo.",
    rating: 5
  },
  {
    name: "João Santos",
    initials: "JS",
    text: "Os packs de estudos são perfeitos! Estou conseguindo revisar tudo em menos tempo e com muito mais qualidade.",
    rating: 5
  },
  {
    name: "Ana Costa",
    initials: "AC",
    text: "Melhor investimento que fiz para minha preparação! Estou muito mais confiante para a prova do ENEM.",
    rating: 5
  }
];

export default function TestimonialsSection() {
  return (
    <section id="depoimentos" className="py-16 md:py-24 bg-muted/30">
      <div className="container mx-auto max-w-6xl px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-5xl font-black text-foreground mb-4" data-testid="text-testimonials-title">
            O que nossos alunos dizem
          </h2>
          <p className="text-lg text-muted-foreground" data-testid="text-testimonials-subtitle">
            Resultados reais de quem já turbinou os estudos
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <Card
              key={index}
              className="p-6 bg-card shadow-md hover:shadow-lg transition-all"
              data-testid={`card-testimonial-${index}`}
            >
              <div className="space-y-4">
                {/* Stars */}
                <div className="flex gap-1" data-testid={`stars-${index}`}>
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>

                {/* Text */}
                <p className="text-sm text-foreground leading-relaxed" data-testid={`text-testimonial-${index}`}>
                  "{testimonial.text}"
                </p>

                {/* Author */}
                <div className="flex items-center gap-3 pt-2 border-t">
                  <Avatar className="h-10 w-10">
                    <AvatarFallback className="bg-primary text-primary-foreground font-semibold">
                      {testimonial.initials}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm font-bold text-foreground" data-testid={`text-name-${index}`}>
                      {testimonial.name}
                    </p>
                    <p className="text-xs text-muted-foreground">Aluno ENEM Turbo</p>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
