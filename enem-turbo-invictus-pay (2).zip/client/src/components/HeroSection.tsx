import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Rocket, CheckCircle } from "lucide-react";
import { useState } from "react";

const quizQuestions = [
  {
    question: "Quanto tempo você tem para estudar por dia?",
    options: [
      { text: "Menos de 2 horas", value: "low" },
      { text: "2 a 4 horas", value: "medium" },
      { text: "Mais de 4 horas", value: "high" }
    ]
  },
  {
    question: "Qual sua maior dificuldade?",
    options: [
      { text: "Falta de organização", value: "organization" },
      { text: "Não consigo revisar tudo", value: "review" },
      { text: "Dificuldade nas matérias", value: "content" }
    ]
  },
  {
    question: "Qual área precisa de mais atenção?",
    options: [
      { text: "Matemática e Ciências", value: "exatas" },
      { text: "Linguagens e Redação", value: "linguagens" },
      { text: "Humanas", value: "humanas" }
    ]
  }
];

export default function HeroSection() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<string[]>([]);
  const [showResult, setShowResult] = useState(false);

  const handleAnswer = (value: string) => {
    const newAnswers = [...answers, value];
    setAnswers(newAnswers);

    if (currentQuestion < quizQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setShowResult(true);
    }
  };

  const scrollToInscricao = () => {
    const element = document.getElementById('inscricao');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setAnswers([]);
    setShowResult(false);
  };

  return (
    <section id="inicio" className="gradient-bg pt-24 pb-16 md:pt-32 md:pb-24">
      <div className="container mx-auto max-w-6xl px-4">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          {/* Left side - Text */}
          <div className="flex-1 text-white space-y-6">
            <Badge 
              className="bg-white/20 text-white border-white/30 hover-elevate active-elevate-2 backdrop-blur-sm inline-flex items-center gap-2"
              data-testid="badge-promotion"
            >
              <Rocket className="h-4 w-4" />
              Turbo seus estudos
            </Badge>
            
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-black leading-tight" data-testid="text-hero-title">
              Acelere sua nota no ENEM com o ENEM TURBO 🚀
            </h1>
            
            <p className="text-lg md:text-xl text-white/90 font-medium max-w-2xl" data-testid="text-hero-subtitle">
              Packs de estudos completos e organizados para turbinar sua preparação.
            </p>
            
            <Button 
              size="lg" 
              onClick={scrollToInscricao}
              className="bg-accent text-accent-foreground hover:bg-accent/90 font-bold text-base md:text-lg px-8 md:px-12 py-6 md:py-7 rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
              data-testid="button-cta-hero"
            >
              Começar agora
            </Button>
          </div>

          {/* Right side - Quiz */}
          <div className="flex-1 w-full max-w-lg">
            <Card className="bg-white/10 backdrop-blur-md border-white/20 p-6 md:p-8 text-white" data-testid="quiz-container">
              {!showResult ? (
                <div className="space-y-6">
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-sm font-semibold" data-testid="quiz-progress">
                      Pergunta {currentQuestion + 1} de {quizQuestions.length}
                    </span>
                    <div className="flex gap-1">
                      {quizQuestions.map((_, index) => (
                        <div
                          key={index}
                          className={`h-2 w-8 rounded-full ${
                            index <= currentQuestion ? 'bg-accent' : 'bg-white/30'
                          }`}
                        />
                      ))}
                    </div>
                  </div>

                  <h3 className="text-xl md:text-2xl font-bold mb-6" data-testid="quiz-question">
                    {quizQuestions[currentQuestion].question}
                  </h3>

                  <div className="space-y-3">
                    {quizQuestions[currentQuestion].options.map((option, index) => (
                      <Button
                        key={index}
                        onClick={() => handleAnswer(option.value)}
                        className="w-full bg-white/10 hover:bg-white/20 border border-white/30 text-white justify-start text-left h-auto py-4 px-6"
                        data-testid={`quiz-option-${index}`}
                      >
                        {option.text}
                      </Button>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="space-y-6 text-center">
                  <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mx-auto">
                    <CheckCircle className="w-10 h-10 text-white" />
                  </div>
                  
                  <h3 className="text-2xl md:text-3xl font-black" data-testid="quiz-result-title">
                    Perfeito! 🎯
                  </h3>
                  
                  <p className="text-base md:text-lg text-white/90" data-testid="quiz-result-message">
                    Com base nas suas respostas, os <span className="font-bold text-accent">Packs ENEM Turbo</span> são ideais para você! 
                    Material completo e organizado para turbinar seus estudos.
                  </p>

                  <div className="space-y-3 pt-4">
                    <Button 
                      size="lg"
                      onClick={scrollToInscricao}
                      className="w-full bg-accent text-accent-foreground hover:bg-accent/90 font-bold py-6"
                      data-testid="button-quiz-cta"
                    >
                      Quero meus packs agora! ✅
                    </Button>
                    
                    <Button
                      variant="ghost"
                      onClick={resetQuiz}
                      className="w-full text-white/80 hover:text-white hover:bg-white/10"
                      data-testid="button-quiz-reset"
                    >
                      Refazer diagnóstico
                    </Button>
                  </div>
                </div>
              )}
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
