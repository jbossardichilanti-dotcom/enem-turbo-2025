import TestimonialsSection from '../TestimonialsSection'

export default function TestimonialsSectionExample() {
  return <TestimonialsSection />
}
