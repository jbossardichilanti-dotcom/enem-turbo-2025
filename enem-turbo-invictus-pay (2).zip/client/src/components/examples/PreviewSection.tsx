import PreviewSection from '../PreviewSection'

export default function PreviewSectionExample() {
  return <PreviewSection />
}
