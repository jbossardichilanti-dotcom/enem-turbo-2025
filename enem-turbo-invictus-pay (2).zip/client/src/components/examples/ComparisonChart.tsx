import ComparisonChart from '../ComparisonChart'

export default function ComparisonChartExample() {
  return <ComparisonChart />
}
