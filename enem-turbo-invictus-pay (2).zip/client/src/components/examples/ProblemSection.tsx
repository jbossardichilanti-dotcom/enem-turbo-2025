import ProblemSection from '../ProblemSection'

export default function ProblemSectionExample() {
  return <ProblemSection />
}
