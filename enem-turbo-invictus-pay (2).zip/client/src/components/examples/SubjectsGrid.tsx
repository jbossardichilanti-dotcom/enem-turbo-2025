import SubjectsGrid from '../SubjectsGrid'

export default function SubjectsGridExample() {
  return <SubjectsGrid />
}
