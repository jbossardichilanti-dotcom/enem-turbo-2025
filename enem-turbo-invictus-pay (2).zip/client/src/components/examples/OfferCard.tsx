import OfferCard from '../OfferCard'

export default function OfferCardExample() {
  return <OfferCard />
}
