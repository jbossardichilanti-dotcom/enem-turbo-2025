export default function ProblemSection() {
  return (
    <section className="py-16 md:py-24 bg-deep-space relative">
      <div className="absolute inset-0 bg-gradient-to-b from-midnight-navy/50 to-transparent"></div>
      
      <div className="container relative mx-auto max-w-5xl px-4">
        <div className="grid md:grid-cols-2 gap-6 md:gap-8">
          <div className="glass-panel rounded-2xl p-6 md:p-8 text-center space-y-4">
            <h2 className="text-2xl md:text-4xl font-bold text-white leading-tight" data-testid="text-problem-title">
              O problema não é você.
            </h2>
            <h2 className="text-2xl md:text-4xl font-bold bg-gradient-to-r from-neon-violet to-neon-magenta bg-clip-text text-transparent leading-tight" data-testid="text-problem-subtitle">
              O problema é o tempo.
            </h2>
          </div>
          
          <div className="glass-panel rounded-2xl p-6 md:p-8 flex items-center justify-center">
            <p className="text-base md:text-xl text-gray-300 font-semibold leading-relaxed" data-testid="text-solution">
              Por isso criamos o <span className="text-neon-cyan font-black">ENEM Turbo2025</span>: <span className="text-neon-magenta font-black">packs do ENEM</span> prontos das matérias mais importantes.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
