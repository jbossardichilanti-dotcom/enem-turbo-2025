import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BookOpen, Calculator, Globe, FlaskConical, PenTool, Star } from "lucide-react";

const subjects = [
  {
    title: "Linguagens",
    icon: BookOpen,
    color: "hsl(var(--purple-postit))",
    description: "Literatura, Gramática e Interpretação",
    topics: ["Figuras de linguagem", "Análise sintática", "Interpretação de textos"],
    curiosity: "45% das questões são de interpretação!"
  },
  {
    title: "Matemática",
    icon: Calculator,
    color: "hsl(var(--pink-postit))",
    description: "Álgebra, Geometria e Estatística",
    topics: ["Funções e gráficos", "Geometria espacial", "Probabilidade"],
    curiosity: "Estatística cai em 30% das provas"
  },
  {
    title: "Ciências Humanas",
    icon: Globe,
    color: "hsl(var(--green-postit))",
    description: "História, Geografia, Filosofia e Sociologia",
    topics: ["Brasil Colônia", "Geopolítica", "Filosofia moderna", "Sociologia urbana"],
    curiosity: "Geografia é a matéria com mais questões"
  },
  {
    title: "Ciências da Natureza",
    icon: FlaskConical,
    color: "hsl(var(--yellow-postit))",
    description: "Física, Química e Biologia",
    topics: ["Mecânica e energia", "Química orgânica", "Ecologia e evolução"],
    curiosity: "Biologia representa 40% dessa área"
  },
  {
    title: "Redação",
    icon: PenTool,
    color: "hsl(var(--orange-postit))",
    description: "Técnicas e modelos de redação nota 1000",
    topics: ["Estrutura dissertativa", "Repertório sociocultural", "Proposta de intervenção"],
    curiosity: "Vale 1000 pontos - 20% da sua nota!"
  }
];

export default function LearningSection() {
  return (
    <section id="conteudo" className="py-16 md:py-24 bg-background">
      <div className="container mx-auto max-w-6xl px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-5xl font-black text-foreground mb-4" data-testid="text-learning-title">
            O que você vai aprender
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto" data-testid="text-learning-subtitle">
            Conteúdo completo e organizado para todas as áreas do ENEM
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {subjects.map((subject, index) => (
            <Card
              key={subject.title}
              className="postit-card p-6 border-2 shadow-md hover:shadow-lg transition-all"
              style={{ borderColor: subject.color }}
              data-testid={`card-subject-${index}`}
            >
              <div className="flex flex-col space-y-4">
                <div className="flex items-start gap-4">
                  <div
                    className="p-3 rounded-xl flex-shrink-0"
                    style={{ backgroundColor: subject.color }}
                  >
                    <subject.icon className="h-6 w-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-foreground mb-1" data-testid={`text-subject-title-${index}`}>
                      {subject.title}
                    </h3>
                    <p className="text-xs text-muted-foreground" data-testid={`text-subject-description-${index}`}>
                      {subject.description}
                    </p>
                  </div>
                </div>

                <div className="space-y-2">
                  <p className="text-xs font-semibold text-foreground">📚 Principais tópicos:</p>
                  <div className="flex flex-wrap gap-1">
                    {subject.topics.map((topic, topicIndex) => (
                      <Badge
                        key={topicIndex}
                        variant="secondary"
                        className="text-xs font-normal"
                        data-testid={`badge-topic-${index}-${topicIndex}`}
                      >
                        {topic}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="pt-2 border-t border-border">
                  <div className="flex items-start gap-2 text-xs text-muted-foreground">
                    <Star className="h-3 w-3 text-yellow-500 flex-shrink-0 mt-0.5" />
                    <span data-testid={`text-curiosity-${index}`}>{subject.curiosity}</span>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
