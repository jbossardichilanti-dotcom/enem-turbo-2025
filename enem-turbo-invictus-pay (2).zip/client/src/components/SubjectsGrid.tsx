import { Button } from "@/components/ui/button";
import { BookOpen, Book, FileText, Globe, Calculator, Clock, Map, Brain, Users, Flag, Dna, Atom, FlaskConical, Palette } from "lucide-react";

const subjects = [
  { name: "Português", icon: BookOpen },
  { name: "Literatura", icon: Book },
  { name: "Redação", icon: FileText },
  { name: "Inglês", icon: Globe },
  { name: "Espanhol", icon: Globe },
  { name: "Matemática", icon: Calculator },
  { name: "História", icon: Clock },
  { name: "Geografia", icon: Map },
  { name: "Filosofia", icon: Brain },
  { name: "Sociologia", icon: Users },
  { name: "Geopolítica", icon: Flag },
  { name: "Biologia", icon: Dna },
  { name: "Física", icon: Atom },
  { name: "Química", icon: FlaskConical },
  { name: "Arte", icon: Palette },
];

export default function SubjectsGrid() {
  return (
    <section className="py-16 md:py-24 bg-deep-space relative">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(123,77,255,0.1),transparent_70%)]"></div>
      
      <div className="container relative mx-auto max-w-6xl px-4">
        <div className="mb-12 md:mb-16 text-center">
          <div className="inline-block glass-panel rounded-xl px-8 py-3 mb-8">
            <span className="text-2xl md:text-3xl font-black bg-gradient-to-r from-neon-cyan to-neon-violet bg-clip-text text-transparent" data-testid="img-logo">
              ENEM TURBO
            </span>
          </div>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 md:gap-4 mb-16">
          {subjects.map((subject, index) => {
            const Icon = subject.icon;
            return (
              <Button
                key={index}
                className="bg-neon-cyan/10 hover:bg-neon-cyan/20 border border-neon-cyan/30 text-neon-cyan font-semibold rounded-lg py-5 md:py-6 text-xs md:text-sm backdrop-blur-sm transition-all duration-300 hover:shadow-[0_0_20px_rgba(54,240,255,0.3)]"
                data-testid={`button-subject-${subject.name.toLowerCase()}`}
              >
                <Icon className="w-3 h-3 md:w-4 md:h-4 mr-2" />
                {subject.name}
              </Button>
            );
          })}
        </div>
        
        <div className="text-center px-2">
          <h3 className="text-xl md:text-3xl font-bold text-white mb-8 leading-tight" data-testid="text-comparison-title">
            Aumente sua chance de aprovação com ENEM Turbo:
          </h3>
        </div>
      </div>
    </section>
  );
}
