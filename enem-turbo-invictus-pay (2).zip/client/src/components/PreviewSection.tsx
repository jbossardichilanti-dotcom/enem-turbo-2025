import { Button } from "@/components/ui/button";
import laptopMockup from "@assets/3ce9b2d9-27b6-45b9-b190-2f67c053811b_1759695598448.png";
import sheetsPreview from "@assets/dde15215-0d3f-4bde-b8d6-71b78263a134_1759695343352.png";

export default function PreviewSection() {
  return (
    <section className="py-16 md:py-24 bg-deep-space relative">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-midnight-navy/50 to-transparent"></div>
      
      <div className="container relative mx-auto max-w-6xl px-4 space-y-12 md:space-y-20">
        <div className="glass-panel rounded-3xl p-6 md:p-12 border-neon-violet/20">
          <img 
            src={laptopMockup} 
            alt="Packs de estudos digitais no laptop" 
            className="w-full h-auto rounded-xl"
            data-testid="img-laptop-mockup"
          />
        </div>
        
        <div className="text-center px-4">
          <Button 
            size="lg" 
            className="bg-neon-cyan hover:bg-neon-cyan/90 text-deep-space font-bold text-base md:text-lg px-8 md:px-12 py-6 md:py-7 rounded-full shadow-[0_0_30px_rgba(54,240,255,0.4)] hover:shadow-[0_0_40px_rgba(54,240,255,0.6)] transition-all duration-300 w-full max-w-md"
            data-testid="button-cta-preview"
          >
            Quero meus packs agora ✅
          </Button>
        </div>
      </div>
    </section>
  );
}
