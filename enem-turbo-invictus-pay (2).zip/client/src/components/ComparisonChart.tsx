import { X, CheckCircle } from "lucide-react";
import { Progress } from "@/components/ui/progress";

export default function ComparisonChart() {
  return (
    <section className="py-16 md:py-20 bg-deep-space">
      <div className="container mx-auto max-w-5xl px-4">
        <div className="grid md:grid-cols-2 gap-6 md:gap-12">
          <div className="glass-panel rounded-2xl p-6 md:p-8 text-center space-y-4">
            <div className="flex items-center justify-center gap-2 text-red-400">
              <X className="w-5 h-5 md:w-6 md:h-6" />
              <span className="text-base md:text-lg font-semibold" data-testid="text-without-label">Reprovado</span>
            </div>
            <div className="space-y-3">
              <p className="text-xs md:text-sm text-gray-400 font-medium">Sem o ENEM Turbo 😢</p>
              <Progress value={15} className="h-3 md:h-4 bg-gray-800" data-testid="progress-without" />
              <p className="text-4xl md:text-5xl font-black text-red-400" data-testid="text-without-percentage">15%</p>
            </div>
          </div>
          
          <div className="glass-panel rounded-2xl p-6 md:p-8 text-center space-y-4 border-neon-cyan/20">
            <div className="flex items-center justify-center gap-2 text-neon-cyan">
              <CheckCircle className="w-5 h-5 md:w-6 md:h-6" />
              <span className="text-base md:text-lg font-semibold" data-testid="text-with-label">Aprovado</span>
            </div>
            <div className="space-y-3">
              <p className="text-xs md:text-sm text-gray-400 font-medium">Com ENEM Turbo ⚡</p>
              <Progress value={75} className="h-3 md:h-4 bg-gray-800 [&>div]:bg-gradient-to-r [&>div]:from-neon-cyan [&>div]:to-neon-violet" data-testid="progress-with" />
              <p className="text-4xl md:text-5xl font-black bg-gradient-to-r from-neon-cyan to-neon-violet bg-clip-text text-transparent" data-testid="text-with-percentage">75%</p>
            </div>
          </div>
        </div>
        
        <div className="mt-10 md:mt-16 grid md:grid-cols-2 gap-6 md:gap-12">
          <div className="glass-panel rounded-2xl p-6 md:p-8 text-center space-y-3">
            <p className="text-xs md:text-sm text-gray-400 font-medium">Cansado de estudar 😴</p>
            <Progress value={15} className="h-3 md:h-4 bg-gray-800" />
            <p className="text-4xl md:text-5xl font-black text-red-400">15%</p>
          </div>
          
          <div className="glass-panel rounded-2xl p-6 md:p-8 text-center space-y-3 border-neon-cyan/20">
            <p className="text-xs md:text-sm text-gray-400 font-medium">Mais tempo livre ⚡</p>
            <Progress value={75} className="h-3 md:h-4 bg-gray-800 [&>div]:bg-gradient-to-r [&>div]:from-neon-cyan [&>div]:to-neon-violet" />
            <p className="text-4xl md:text-5xl font-black bg-gradient-to-r from-neon-cyan to-neon-violet bg-clip-text text-transparent">75%</p>
          </div>
        </div>
      </div>
    </section>
  );
}
