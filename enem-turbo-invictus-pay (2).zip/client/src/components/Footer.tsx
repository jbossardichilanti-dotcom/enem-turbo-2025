import { Mail } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-foreground text-background py-12 md:py-16">
      <div className="container mx-auto max-w-6xl px-4">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          {/* Logo */}
          <div>
            <h3 className="text-2xl font-black" data-testid="text-footer-logo">
              ENEM TURBO
            </h3>
          </div>

          {/* Links */}
          <div className="flex flex-wrap justify-center gap-6 text-sm">
            <a
              href="#politica"
              className="hover:text-accent transition-colors"
              data-testid="link-politica"
            >
              Política de Privacidade
            </a>
            <a
              href="#contato"
              className="hover:text-accent transition-colors flex items-center gap-1"
              data-testid="link-contato"
            >
              <Mail className="h-4 w-4" />
              Contato
            </a>
          </div>
        </div>

        <div className="text-center mt-8 pt-8 border-t border-background/20">
          <p className="text-sm opacity-80" data-testid="text-copyright">
            © 2025 ENEM Turbo - Todos os direitos reservados
          </p>
        </div>
      </div>
    </footer>
  );
}
