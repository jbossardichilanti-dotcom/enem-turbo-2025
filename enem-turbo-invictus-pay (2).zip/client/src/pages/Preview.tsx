import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Book, Search, GraduationCap, Lightbulb, Calculator, Globe, Atom } from "lucide-react";
import { enemSynopsis } from "@shared/content";

const subjectIcons: Record<string, any> = {
  "Linguagens": Book,
  "Matemática": Calculator,
  "Ciências Humanas": Globe,
  "Ciências da Natureza": Atom
};

const subjectColors: Record<string, string> = {
  "Linguagens": "bg-purple-500",
  "Matemática": "bg-blue-500",
  "Ciências Humanas": "bg-amber-500",
  "Ciências da Natureza": "bg-green-500"
};

export default function Preview() {
  const [selectedSubject, setSelectedSubject] = useState<string>("Linguagens");
  const [searchQuery, setSearchQuery] = useState("");

  const subjects = Array.from(new Set(enemSynopsis.map(item => item.subject)));
  
  const filteredContent = enemSynopsis.filter(item => {
    const matchesSubject = item.subject === selectedSubject;
    const matchesSearch = searchQuery === "" || 
      item.area.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.topics.some(topic => 
        topic.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        topic.content.toLowerCase().includes(searchQuery.toLowerCase())
      );
    return matchesSubject && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="gradient-bg py-12">
        <div className="container mx-auto max-w-7xl px-4 text-center text-white">
          <GraduationCap className="w-16 h-16 mx-auto mb-4" />
          <h1 className="text-4xl md:text-5xl font-black mb-4" data-testid="text-preview-title">
            Conteúdo Completo ENEM Turbo
          </h1>
          <p className="text-lg md:text-xl text-white/90 max-w-3xl mx-auto" data-testid="text-preview-subtitle">
            Explore todo o material educacional com explicações detalhadas, fórmulas, exemplos práticos e dicas para o ENEM
          </p>
        </div>
      </div>

      <div className="container mx-auto max-w-7xl px-4 py-8">
        {/* Search */}
        <div className="mb-6">
          <div className="relative max-w-xl mx-auto">
            <Search className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
            <Input
              placeholder="Buscar por tema, tópico ou palavra-chave..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
              data-testid="input-search-content"
            />
          </div>
        </div>

        {/* Subject Tabs */}
        <Tabs value={selectedSubject} onValueChange={setSelectedSubject} className="w-full">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 mb-8" data-testid="tabs-subjects">
            {subjects.map((subject) => {
              const Icon = subjectIcons[subject] || Book;
              const count = enemSynopsis.filter(item => item.subject === subject).reduce((acc, item) => acc + item.topics.length, 0);
              return (
                <TabsTrigger key={subject} value={subject} className="gap-2" data-testid={`tab-${subject.toLowerCase().replace(/\s/g, '-')}`}>
                  <Icon className="w-4 h-4" />
                  <span className="hidden sm:inline">{subject}</span>
                  <Badge variant="secondary" className="ml-1">{count}</Badge>
                </TabsTrigger>
              );
            })}
          </TabsList>

          {subjects.map((subject) => (
            <TabsContent key={subject} value={subject} className="space-y-6">
              {filteredContent.length === 0 ? (
                <Card>
                  <CardContent className="py-12 text-center">
                    <p className="text-muted-foreground">Nenhum conteúdo encontrado para "{searchQuery}"</p>
                  </CardContent>
                </Card>
              ) : (
                filteredContent.map((area, areaIdx) => (
                  <Card key={areaIdx} className="hover-elevate" data-testid={`card-area-${areaIdx}`}>
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="text-2xl flex items-center gap-2">
                            <div className={`w-3 h-3 rounded-full ${subjectColors[subject]}`} />
                            {area.area}
                          </CardTitle>
                          <CardDescription className="mt-2">
                            {area.topics.length} tópico{area.topics.length !== 1 ? 's' : ''} detalhado{area.topics.length !== 1 ? 's' : ''}
                          </CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      {area.topics.map((topic, topicIdx) => (
                        <div key={topicIdx} className="space-y-4 pb-6 border-b last:border-b-0" data-testid={`topic-${topicIdx}`}>
                          {/* Título do Tópico */}
                          <h3 className="text-xl font-bold text-foreground flex items-center gap-2">
                            <Lightbulb className="w-5 h-5 text-primary" />
                            {topic.title}
                          </h3>

                          {/* Conteúdo Principal */}
                          <div className="prose prose-sm max-w-none">
                            <p className="text-muted-foreground whitespace-pre-line leading-relaxed">
                              {topic.content}
                            </p>
                          </div>

                          {/* Fórmulas */}
                          {topic.formulas && (
                            <div className="bg-violet-50 dark:bg-violet-950/30 border border-violet-200 dark:border-violet-800 rounded-md p-4">
                              <h4 className="text-sm font-bold text-violet-700 dark:text-violet-300 mb-2 flex items-center gap-2">
                                📐 Fórmulas Importantes
                              </h4>
                              <pre className="text-xs font-mono text-violet-900 dark:text-violet-200 whitespace-pre-line">
                                {topic.formulas}
                              </pre>
                            </div>
                          )}

                          {/* Exemplos */}
                          {topic.examples && (
                            <div className="bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 rounded-md p-4">
                              <h4 className="text-sm font-bold text-emerald-700 dark:text-emerald-300 mb-2 flex items-center gap-2">
                                💡 Exemplos Práticos
                              </h4>
                              <p className="text-sm text-emerald-900 dark:text-emerald-200 whitespace-pre-line">
                                {topic.examples}
                              </p>
                            </div>
                          )}

                          {/* Dicas ENEM */}
                          {topic.tips && (
                            <div className="bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 rounded-md p-4">
                              <h4 className="text-sm font-bold text-red-700 dark:text-red-300 mb-2 flex items-center gap-2">
                                🎯 Dica para o ENEM
                              </h4>
                              <p className="text-sm text-red-900 dark:text-red-200 italic whitespace-pre-line">
                                {topic.tips}
                              </p>
                            </div>
                          )}

                          {/* Videoaulas */}
                          {topic.videoLinks && (
                            <div className="bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 rounded-md p-4">
                              <h4 className="text-sm font-bold text-blue-700 dark:text-blue-300 mb-2 flex items-center gap-2">
                                🎥 Videoaulas Recomendadas
                              </h4>
                              <p className="text-sm text-blue-900 dark:text-blue-200">
                                {topic.videoLinks}
                              </p>
                            </div>
                          )}
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                ))
              )}
            </TabsContent>
          ))}
        </Tabs>

        {/* Stats */}
        <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-4">
          {subjects.map((subject) => {
            const topicCount = enemSynopsis
              .filter(item => item.subject === subject)
              .reduce((acc, item) => acc + item.topics.length, 0);
            const Icon = subjectIcons[subject];
            return (
              <Card key={subject} className="text-center">
                <CardContent className="py-6">
                  <Icon className="w-8 h-8 mx-auto mb-2 text-primary" />
                  <div className="text-3xl font-black text-primary">{topicCount}</div>
                  <div className="text-xs text-muted-foreground mt-1">{subject}</div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}
