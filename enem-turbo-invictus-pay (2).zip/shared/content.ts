export interface SynopsisContent {
  subject: string;
  area: string;
  topics: {
    title: string;
    content: string;
    examples?: string;
    formulas?: string;
    tips?: string;
    videoLinks?: string;
  }[];
}

export const enemSynopsis: SynopsisContent[] = [
  {
    subject: "Linguagens",
    area: "Língua Portuguesa",
    topics: [
      {
        title: "Interpretação de Textos",
        content: "A interpretação de textos é a habilidade de compreender globalmente um texto, identificando suas ideias principais e secundárias, e fazendo inferências sobre informações implícitas. No ENEM, você deve analisar não apenas o texto verbal, mas também elementos visuais como título, subtítulos, gráficos, imagens e infográficos que complementam a mensagem.\n\nPara interpretar bem um texto: 1) Faça uma leitura global primeiro, 2) Identifique o tema central, 3) Reconheça a tese do autor (se houver), 4) Observe os argumentos utilizados, 5) Analise elementos não-verbais, 6) Identifique relações de causa e consequência.",
        examples: "Exemplo prático: Em uma charge política, você deve observar não só o texto escrito, mas também os desenhos, expressões faciais, símbolos e referências culturais para compreender a crítica social implícita.",
        tips: "DICA ENEM: Nunca marque a alternativa apenas porque ela contém palavras do texto. Procure a alternativa que expressa a mesma IDEIA do texto, mesmo que use palavras diferentes. Cuidado com alternativas que distorcem o sentido original.",
        videoLinks: "Videoaulas recomendadas: 'Interpretação de Textos - Prof. Noslen' no YouTube"
      },
      {
        title: "Gêneros Textuais",
        content: "Os gêneros textuais são formas de organizar a linguagem de acordo com a situação comunicativa. Principais gêneros cobrados no ENEM:\n\nNARRATIVO: conta uma história com personagens, tempo, espaço e enredo (contos, crônicas, notícias).\n\nDISSERTATIVO-ARGUMENTATIVO: defende uma tese com argumentos (artigos de opinião, editorial, redação do ENEM).\n\nDESCRITIVO: caracteriza seres, objetos ou lugares (retrato, paisagem).\n\nINJUNTIVO: dá instruções ou ordens (receitas, manuais, leis).\n\nEXPOSITIVO: apresenta informações sobre um assunto (verbete, relatório).",
        examples: "Uma RECEITA (injuntivo) usa verbos no imperativo: 'Misture os ingredientes'. Uma NOTÍCIA (narrativo) responde: O quê? Quem? Quando? Onde? Como? Por quê?",
        tips: "DICA ENEM: Identifique marcas linguísticas de cada gênero: verbos no imperativo (injuntivo), verbos no passado (narrativo), conectivos argumentativos (dissertativo), adjetivos abundantes (descritivo).",
        videoLinks: "Videoaulas: 'Gêneros Textuais - Professor Noslen' e 'Tipologia Textual - Descomplica'"
      },
      {
        title: "Funções da Linguagem",
        content: "As funções da linguagem representam as diferentes intenções comunicativas. Roman Jakobson definiu 6 funções:\n\nEMOTIVA (expressiva): foca no emissor, expressa emoções. Ex: 'Que dia lindo!'\n\nREFERENCIAL (denotativa): foca no assunto, informa objetivamente. Ex: notícias, textos científicos.\n\nCONATIVA (apelativa): foca no receptor, tenta persuadir. Ex: propagandas, discursos políticos.\n\nFÁTICA: foca no canal, testa ou mantém o contato. Ex: 'Alô?', 'Entendeu?'\n\nMETALINGUÍSTICA: foca no código, a linguagem fala sobre si mesma. Ex: dicionário, gramática.\n\nPOÉTICA: foca na mensagem, valoriza a forma. Ex: poesia, slogans criativos.",
        examples: "PROPAGANDA: 'Compre já!' = conativa (convence). POEMA: uso de metáforas e rimas = poética. NOTÍCIA: fatos objetivos = referencial.",
        tips: "DICA ENEM: Uma mesma mensagem pode ter mais de uma função, mas sempre há uma PREDOMINANTE. Identifique qual elemento da comunicação está em destaque: emissor, receptor, mensagem, canal, código ou contexto.",
        videoLinks: "Videoaulas: 'Funções da Linguagem - Português Play' e 'Funções da Linguagem ENEM - ProEnem'"
      },
      {
        title: "Figuras de Linguagem",
        content: "As figuras de linguagem são recursos expressivos que conferem maior impacto e emoção ao texto:\n\nMETÁFORA: comparação implícita. Ex: 'Meu coração é um balde despejado' (não usa 'como').\n\nCOMPARAÇÃO: usa conectivo comparativo. Ex: 'Olhos brilhantes como estrelas'.\n\nMETONÍMIA: substituição de um termo por outro relacionado. Ex: 'Ler Machado de Assis' (obra pelo autor).\n\nHIPÉRBOLE: exagero intencional. Ex: 'Chorei rios de lágrimas'.\n\nEUFEMISMO: suaviza expressão desagradável. Ex: 'Ele partiu desta vida' (morreu).\n\nANTÍTESE: oposição de ideias. Ex: 'Amor e ódio caminham juntos'.\n\nIRONIA: diz o contrário do que pensa. Ex: 'Que belo presente!' (sobre algo ruim).\n\nPERSONIFICAÇÃO: atribui características humanas a seres inanimados. Ex: 'O vento sussurrava'.",
        examples: "Na música 'Exagerado' (Cazuza): 'Eu nunca mais vou respirar se você não me notar' = HIPÉRBOLE (exagero emocional).",
        tips: "DICA ENEM: Figuras de linguagem criam EFEITOS DE SENTIDO. Sempre pergunte: por que o autor usou essa figura? Qual emoção ou ideia ele quis reforçar?",
        videoLinks: "Videoaulas: 'Figuras de Linguagem - Português com Letícia' e 'Figuras de Linguagem para o ENEM - Me Salva!'"
      }
    ]
  },
  {
    subject: "Linguagens",
    area: "Literatura",
    topics: [
      {
        title: "Escolas Literárias Brasileiras",
        content: "QUINHENTISMO (1500-1601): Literatura de informação e catequese. Carta de Pero Vaz de Caminha, poemas do Padre José de Anchieta.\n\nBARROCO (1601-1768): Conflito entre fé e razão, culto ao contraste (antítese). Gregório de Matos (poesia) e Pe. Antônio Vieira (sermões).\n\nARCADISMO (1768-1836): Simplicidade, natureza, razão. Lema: 'Fugere urbem' (fugir da cidade). Cláudio Manuel da Costa, Tomás Antônio Gonzaga.\n\nROMANTISMO (1836-1881): Sentimentalismo, nacionalismo, idealização. Gerações: indianista (Gonçalves Dias), ultrarromântica (Álvares de Azevedo), social (Castro Alves).\n\nREALISMO/NATURALISMO (1881-1893): Objetividade, crítica social. Machado de Assis (realismo psicológico), Aluísio Azevedo (naturalismo científico).\n\nPARNASIANISMO (1880-1922): Arte pela arte, perfeição formal. Olavo Bilac, Raimundo Correia.\n\nSIMBOLISMO (1893-1922): Subjetivismo, musicalidade, sinestesia. Cruz e Sousa, Alphonsus de Guimaraens.\n\nPRÉ-MODERNISMO (1902-1922): Realidade brasileira, regionalismo. Euclides da Cunha, Lima Barreto, Monteiro Lobato.\n\nMODERNISMO (1922-1945): Ruptura, experimentação, nacionalismo crítico. 1ª fase: Oswald/Mário de Andrade. 2ª fase: Carlos Drummond, Cecília Meireles, Graciliano Ramos. 3ª fase: Guimarães Rosa, Clarice Lispector.",
        examples: "BARROCO: 'Triste Bahia! Oh quão dessemelhante' (Gregório de Matos) - antítese tristeza/alegria. MODERNISMO: 'No meio do caminho tinha uma pedra' (Drummond) - repetição e cotidiano.",
        tips: "DICA ENEM: Relacione cada escola literária ao CONTEXTO HISTÓRICO. Romantismo = independência do Brasil. Modernismo = Semana de 22. Isso ajuda a entender os temas das obras.",
        videoLinks: "Videoaulas: 'Escolas Literárias - Aulalivre' e 'Literatura Brasileira Completa - Curso Enem Gratuito'"
      },
      {
        title: "Análise Literária",
        content: "Elementos da narrativa que você deve dominar:\n\nNARRADOR: quem conta a história. Pode ser em 1ª pessoa (participa da história) ou 3ª pessoa (observador onisciente ou neutro).\n\nPERSONAGENS: protagonista (principal), antagonista (opositor), secundários. Podem ser planas (não evoluem) ou redondas (complexas).\n\nTEMPO: cronológico (linear) ou psicológico (fluxo de consciência, não linear).\n\nESPAÇO: físico (local geográfico) e psicológico (interior das personagens).\n\nENREDO: situação inicial → conflito → clímax → desfecho.\n\nFOCO NARRATIVO: ponto de vista adotado.\n\nDISCURSO: direto (personagem fala), indireto (narrador conta) ou indireto livre (fusão dos dois).\n\nINTERTEXTUALIDADE: diálogo entre textos (paródia, paráfrase, citação, alusão).",
        examples: "Dom Casmurro (Machado de Assis): narrador em 1ª pessoa não confiável, tempo psicológico (memórias), intertextualidade com Otelo de Shakespeare.",
        tips: "DICA ENEM: Questões sobre intertextualidade são frequentes. Identifique se um texto retoma outro de forma crítica (paródia) ou reverente (paráfrase).",
        videoLinks: "Videoaulas: 'Elementos da Narrativa - Brasil Escola' e 'Foco Narrativo - Descomplica'"
      }
    ]
  },
  {
    subject: "Matemática",
    area: "Álgebra e Aritmética",
    topics: [
      {
        title: "Razão e Proporção",
        content: "RAZÃO é a divisão entre duas grandezas: a/b.\n\nPROPORÇÃO é a igualdade entre duas razões: a/b = c/d.\n\nPropriedade fundamental: a × d = b × c (produto dos meios = produto dos extremos).\n\nGRANDEZAS DIRETAMENTE PROPORCIONAIS: quando uma aumenta, a outra aumenta na mesma proporção. Exemplo: velocidade e distância (com tempo fixo).\n\nGRANDEZAS INVERSAMENTE PROPORCIONAIS: quando uma aumenta, a outra diminui. Exemplo: velocidade e tempo (com distância fixa).\n\nREGRA DE TRÊS SIMPLES: resolve problemas com 2 grandezas. Monte a proporção e resolva.\n\nREGRA DE TRÊS COMPOSTA: 3 ou mais grandezas. Fixe uma e compare as outras duas a duas.\n\nPORCENTAGEM: 15% = 15/100 = 0,15. Para calcular 15% de 200: 200 × 0,15 = 30.\n\nJUROS SIMPLES: J = C × i × t (capital × taxa × tempo).\n\nJUROS COMPOSTOS: M = C × (1 + i)^t",
        formulas: "Proporção: a/b = c/d → a×d = b×c\nJuros Simples: J = C × i × t\nJuros Compostos: M = C × (1 + i)^t\nPorcentagem: P% de N = (P/100) × N",
        examples: "Se 5 operários constroem uma casa em 30 dias, quantos dias levam 10 operários? Grandezas inversamente proporcionais: 5/10 = x/30 → 10x = 150 → x = 15 dias.",
        tips: "DICA ENEM: Na regra de três composta, use setas: ↑↓ = inversamente proporcionais (inverte a fração). ↑↑ ou ↓↓ = diretamente proporcionais (mantém).",
        videoLinks: "Videoaulas: 'Razão e Proporção - Ferretto Matemática' e 'Regra de Três - Professor Ferreto'"
      },
      {
        title: "Equações e Inequações",
        content: "EQUAÇÃO DO 1º GRAU: ax + b = 0. Solução: x = -b/a.\n\nEQUAÇÃO DO 2º GRAU: ax² + bx + c = 0.\nFórmula de Bhaskara: x = [-b ± √(b² - 4ac)] / 2a\nDiscriminante Δ = b² - 4ac:\n- Δ > 0: duas raízes reais distintas\n- Δ = 0: uma raiz real (raiz dupla)\n- Δ < 0: não há raízes reais\n\nRelações de Girard: soma das raízes = -b/a, produto = c/a.\n\nSISTEMAS LINEARES: conjunto de equações. Métodos: substituição, adição, comparação.\n\nINEQUAÇÕES: desigualdades. Mesmas regras das equações, mas ao multiplicar/dividir por número negativo, inverte o sinal.\n\nEQUAÇÕES EXPONENCIAIS: mesma base → iguala expoentes. Exemplo: 2^x = 8 → 2^x = 2³ → x = 3.\n\nEQUAÇÕES LOGARÍTMICAS: log_a(x) = b → x = a^b.",
        formulas: "Bhaskara: x = [-b ± √Δ] / 2a onde Δ = b² - 4ac\nSoma das raízes: S = -b/a\nProduto das raízes: P = c/a\nLogaritmo: log_a(b) = x ↔ a^x = b",
        examples: "Resolver 2x² - 7x + 3 = 0:\nΔ = 49 - 24 = 25\nx = (7 ± 5)/4 → x₁ = 3 ou x₂ = 0,5",
        tips: "DICA ENEM: Para equações do 2º grau, primeiro tente FATORAR (se possível) antes de usar Bhaskara. É mais rápido! Procure dois números que somados deem -b/a e multiplicados deem c/a.",
        videoLinks: "Videoaulas: 'Equação do 2º Grau - Equaciona Com Paulo Pereira' e 'Sistemas Lineares - Matemática Rio'"
      },
      {
        title: "Funções",
        content: "FUNÇÃO é uma relação entre dois conjuntos onde cada elemento do domínio se relaciona com um único elemento do contradomínio.\n\nFUNÇÃO AFIM: f(x) = ax + b (reta)\n- a > 0: crescente\n- a < 0: decrescente\n- a = 0: constante\n- Raiz: x = -b/a\n\nFUNÇÃO QUADRÁTICA: f(x) = ax² + bx + c (parábola)\n- a > 0: concavidade para cima (U)\n- a < 0: concavidade para baixo (∩)\n- Vértice: xv = -b/2a, yv = -Δ/4a\n- Raízes: Bhaskara\n\nFUNÇÃO EXPONENCIAL: f(x) = a^x\n- a > 1: crescente\n- 0 < a < 1: decrescente\n- Passa sempre por (0,1)\n\nFUNÇÃO LOGARÍTMICA: f(x) = log_a(x)\n- a > 1: crescente\n- 0 < a < 1: decrescente\n- Passa sempre por (1,0)\n\nFUNÇÃO MODULAR: f(x) = |x|\n- Sempre não-negativa\n- Gráfico em V",
        formulas: "Função Afim: f(x) = ax + b\nVértice da Parábola: xv = -b/2a, yv = -Δ/4a\nPropriedades dos Logs: log(a×b) = log(a) + log(b)\nlog(a/b) = log(a) - log(b)\nlog(a^n) = n×log(a)",
        examples: "Função f(x) = -x² + 4x - 3:\na = -1 < 0 → parábola com concavidade para baixo\nxv = -4/(-2) = 2\nyv = -(16-12)/(-4) = 1\nVértice: (2, 1) = ponto máximo",
        tips: "DICA ENEM: MEMORIZE os formatos dos gráficos! Função afim = reta, quadrática = parábola, exponencial = curva crescente/decrescente sem tocar eixo x, logarítmica = espelho da exponencial, modular = V.",
        videoLinks: "Videoaulas: 'Função Afim - Professora Angela Matemática' e 'Função Quadrática - Equaciona' e 'Função Exponencial e Logarítmica - Ferretto'"
      }
    ]
  },
  {
    subject: "Matemática",
    area: "Geometria",
    topics: [
      {
        title: "Geometria Plana",
        content: "TRIÂNGULOS:\n- Área = (base × altura) / 2\n- Teorema de Pitágoras: a² = b² + c² (triângulo retângulo)\n- Soma dos ângulos internos = 180°\n\nQUADRILÁTEROS:\n- Quadrado: A = lado², P = 4×lado\n- Retângulo: A = base × altura\n- Trapézio: A = [(Base maior + base menor) × altura] / 2\n- Losango: A = (diagonal maior × diagonal menor) / 2\n- Soma dos ângulos internos = 360°\n\nCÍRCULO:\n- Área = π × r²\n- Circunferência (perímetro) = 2πr\n- Setor circular: A = (α/360°) × πr² onde α é o ângulo\n\nPOLÍGONOS REGULARES:\n- Soma ângulos internos: Si = (n-2) × 180°\n- Cada ângulo interno: ai = Si/n\n- Número de diagonais: d = n(n-3)/2",
        formulas: "Pitágoras: a² = b² + c²\nÁrea do triângulo: A = (b×h)/2\nÁrea do círculo: A = πr²\nPerímetro do círculo: C = 2πr\nSoma ângulos internos polígono: Si = (n-2)×180°",
        examples: "Um triângulo retângulo tem catetos 3 e 4. A hipotenusa é: a² = 3² + 4² = 9 + 16 = 25 → a = 5.\n\nUm círculo de raio 10 cm tem área: A = π × 10² = 100π cm² ≈ 314 cm²",
        tips: "DICA ENEM: Triângulos 3-4-5, 5-12-13 e 8-15-17 são pitagóricos famosos (facilitam cálculos). Memorize também que triângulo equilátero de lado L tem altura h = (L√3)/2.",
        videoLinks: "Videoaulas: 'Geometria Plana - Professor Ferreto' e 'Teorema de Pitágoras - Matemática Rio'"
      },
      {
        title: "Geometria Espacial",
        content: "PRISMAS:\n- Volume = Área da base × altura\n- Área lateral = perímetro da base × altura\n- Área total = área lateral + 2×área da base\n\nPIRÂMIDES:\n- Volume = (Área da base × altura) / 3\n- Área lateral = soma das áreas dos triângulos laterais\n\nCILINDRO:\n- Volume = πr²h\n- Área lateral = 2πrh\n- Área total = 2πrh + 2πr²\n\nCONE:\n- Volume = (πr²h) / 3\n- Área lateral = πrg (g = geratriz)\n- Área total = πrg + πr²\n- Relação: g² = r² + h² (Pitágoras)\n\nESFERA:\n- Volume = (4πr³) / 3\n- Área = 4πr²",
        formulas: "Prisma: V = Ab × h\nPirâmide: V = (Ab × h) / 3\nCilindro: V = πr²h\nCone: V = (πr²h) / 3\nEsfera: V = (4πr³) / 3, A = 4πr²",
        examples: "Cilindro com raio 5 cm e altura 10 cm:\nVolume = π × 5² × 10 = 250π cm³\nÁrea lateral = 2π × 5 × 10 = 100π cm²",
        tips: "DICA ENEM: CONE e PIRÂMIDE sempre têm volume dividido por 3. CILINDRO e PRISMA não dividem. Esfera: área = 4πr², volume = (4πr³)/3 (observe o 4 em ambos).",
        videoLinks: "Videoaulas: 'Geometria Espacial - Professor Ferreto' e 'Volume dos Sólidos - Matemática Rio'"
      },
      {
        title: "Geometria Analítica",
        content: "DISTÂNCIA ENTRE DOIS PONTOS:\nd(A,B) = √[(x₂-x₁)² + (y₂-y₁)²]\n\nPONTO MÉDIO:\nM = [(x₁+x₂)/2, (y₁+y₂)/2]\n\nEQUAÇÃO DA RETA:\n- Forma reduzida: y = ax + b (a = coeficiente angular, b = linear)\n- Forma geral: ax + by + c = 0\n- Coeficiente angular: m = (y₂-y₁)/(x₂-x₁) = tan(α)\n\nPOSIÇÕES RELATIVAS ENTRE RETAS:\n- Paralelas: m₁ = m₂\n- Perpendiculares: m₁ × m₂ = -1\n- Concorrentes: m₁ ≠ m₂\n\nEQUAÇÃO DA CIRCUNFERÊNCIA:\n- Centro na origem: x² + y² = r²\n- Centro em (a,b): (x-a)² + (y-b)² = r²\n- Forma geral: x² + y² + Dx + Ey + F = 0\n  Centro: (-D/2, -E/2)\n  Raio: r = √[(D²+E²-4F)/4]",
        formulas: "Distância: d = √[(Δx)² + (Δy)²]\nCoef. angular: m = Δy/Δx = tan(α)\nReta: y = ax + b\nCircunferência: (x-a)² + (y-b)² = r²",
        examples: "Distância entre A(1,2) e B(4,6):\nd = √[(4-1)² + (6-2)²] = √[9+16] = √25 = 5\n\nReta passando por A(0,3) com m=2: y = 2x + 3",
        tips: "DICA ENEM: Retas paralelas têm mesmo coeficiente angular. Retas perpendiculares: multiplique os coeficientes angulares, se der -1, são perpendiculares!",
        videoLinks: "Videoaulas: 'Geometria Analítica - Ferretto Matemática' e 'Equação da Reta - Equaciona'"
      }
    ]
  },
  {
    subject: "Ciências Humanas",
    area: "História do Brasil",
    topics: [
      {
        title: "Brasil Colônia (1500-1822)",
        content: "CICLO DO PAU-BRASIL (1500-1530): Exploração predatória com escambo (troca com indígenas). Sistema de feitorias.\n\nCICLO DO AÇÚCAR (1530-1700): Plantation (monocultura, latifúndio, escravidão, exportação). Capitanias Hereditárias (1534) e Governo-Geral (1549). Invasões holandesas no Nordeste (1624-1654). União Ibérica (1580-1640). Quilombo dos Palmares (Zumbi).\n\nCICLO DO OURO (1700-1822): Mineração em MG, MT, GO. Migração para interior. Cidades como Ouro Preto. Impostos: quinto, derrama. Inconfidência Mineira (1789) - Tiradentes. Conjuração Baiana (1798) - caráter popular.\n\nORGANIZAÇÃO COLONIAL:\n- Economia: mercantilismo, pacto colonial, monocultura\n- Sociedade: senhores, escravos, homens livres pobres\n- Administração: Câmaras Municipais, Governadores\n- Igreja: catequese jesuíta, Tribunal do Santo Ofício",
        examples: "Pacto Colonial: Brasil só podia comerciar com Portugal, vendendo matéria-prima barata e comprando produtos manufaturados caros. Isso gerou exploração e impediu industrialização.",
        tips: "DICA ENEM: Relacione ciclos econômicos com regiões: açúcar (Nordeste), ouro (MG/MT/GO), café (SP/RJ). Entenda que revoltas coloniais tinham motivos ECONÔMICOS (impostos) e políticos (autonomia).",
        videoLinks: "Videoaulas: 'Brasil Colônia - Parabólica' e 'Ciclo do Ouro - História Play'"
      },
      {
        title: "Brasil Império (1822-1889)",
        content: "INDEPENDÊNCIA (1822): Processo conservador, manteve escravidão e monarquia. D. Pedro I proclama independência por pressão da elite agrária. Reconhecimento custou 2 milhões de libras à Inglaterra.\n\nPRIMEIRO REINADO (1822-1831):\n- Constituição de 1824: Poder Moderador (Imperador acima de tudo)\n- Guerra da Cisplatina (perdemos Uruguai)\n- Crise econômica e autoritarismo\n- Abdicação de D. Pedro I em 1831\n\nREGÊNCIAS (1831-1840): Instabilidade, revoltas regionais:\n- Cabanagem (PA), Sabinada (BA), Balaiada (MA), Farroupilha (RS)\n- Golpe da Maioridade: D. Pedro II assume aos 14 anos\n\nSEGUNDO REINADO (1840-1889):\n- Parlamentarismo às avessas (Imperador escolhia o PM)\n- Economia cafeeira (Vale do Paraíba)\n- Guerra do Paraguai (1864-1870)\n- Abolição gradual: Lei Eusébio de Queirós (1850), Ventre Livre (1871), Sexagenários (1885), Áurea (1888)\n- Crise do Império: questão militar, religiosa, abolicionista\n- Proclamação da República (1889): golpe militar de Deodoro da Fonseca",
        examples: "Lei Áurea (1888): Princesa Isabel assina abolição sem indenização aos fazendeiros, que passam a apoiar a República. Um ano depois, monarquia cai.",
        tips: "DICA ENEM: Entenda que a abolição foi GRADUAL e tardia (Brasil foi último país americano). Relacione com pressões inglesas (fim do tráfico) e movimentos abolicionistas internos.",
        videoLinks: "Videoaulas: 'Brasil Império - Descomplica' e 'Segundo Reinado - Brasil Escola'"
      },
      {
        title: "República Brasileira (1889-hoje)",
        content: "REPÚBLICA VELHA (1889-1930):\n- Oligarquias estaduais, coronelismo, voto de cabresto\n- Política café-com-leite (SP e MG alternavam presidência)\n- Revoltas: Canudos, Contestado, Revolta da Vacina, Cangaço\n- Tenentismo (anos 20): militares querem modernização\n- Crise de 1929: queda do café, fim da República Velha\n\nERA VARGAS (1930-1945):\n- Governo Provisório (1930-34): interventores, queima de café\n- Governo Constitucional (1934-37): Constituição de 1934\n- Estado Novo (1937-45): ditadura, censura, DIP, CLT, CSN, nacionalismo\n- Deposição: pressão pós-2ª Guerra\n\nREPÚBLICA DEMOCRÁTICA (1946-1964):\n- Dutra, Vargas (suicídio 1954), JK (50 anos em 5), Jânio (renúncia), Jango\n- Desenvolvimentismo, industrialização (Plano de Metas)\n- Crise política: reformas de base, polarização\n\nDITADURA MILITAR (1964-1985):\n- Golpe civil-militar contra Jango\n- AI-5 (1968): fechamento do regime\n- Milagre econômico + repressão + tortura\n- Crise: choques do petróleo, dívida externa\n- Abertura lenta e gradual: anistia (1979), Diretas Já (1984)\n\nREDEMOCRATIZAÇÃO (1985-hoje):\n- Constituição de 1988 (Cidadã)\n- Plano Real (1994): estabilização econômica\n- Governos: Sarney, Collor, Itamar, FHC, Lula, Dilma, Temer, Bolsonaro, Lula",
        examples: "Estado Novo (Vargas): inspirado em fascismo europeu, mas com trabalhismo nacional. Criou CLT (direitos trabalhistas) e reprimiu comunistas e integralistas.",
        tips: "DICA ENEM: República Velha = oligarquias agrárias. Era Vargas = industrialização e trabalhismo. Ditadura Militar = desenvolvimentismo autoritário, AI-5, repressão. Redemocratização = Constituição 1988.",
        videoLinks: "Videoaulas: 'República Velha - Parabólica' e 'Era Vargas - Descomplica' e 'Ditadura Militar - História Play'"
      }
    ]
  },
  {
    subject: "Ciências Humanas",
    area: "Geografia",
    topics: [
      {
        title: "Geografia Física e Meio Ambiente",
        content: "CLIMA: Fatores (latitude, altitude, maritimidade, massas de ar, correntes marítimas). Climas do Brasil: equatorial (quente e úmido), tropical (estações definidas), semiárido (seco), subtropical (4 estações), tropical de altitude (temperatura amena).\n\nRELEVO: Agentes formadores (internos: tectonismo, vulcanismo, abalos sísmicos; externos: erosão, intemperismo). Formas: planícies, planaltos, depressões, montanhas.\n\nHIDROGRAFIA: Bacias hidrográficas do Brasil (Amazônica - maior do mundo, do Paraná, São Francisco). Aquífero Guarani. Hidrelétricas.\n\nVEGETAÇÃO: Formações brasileiras: Amazônia, Cerrado, Caatinga, Mata Atlântica (mais devastada), Pampa, Pantanal.\n\nQUESTÕES AMBIENTAIS:\n- Desmatamento (Amazônia, Cerrado)\n- Aquecimento global: efeito estufa, mudanças climáticas\n- Poluição: atmosférica, hídrica, solo\n- Desenvolvimento sustentável: satisfazer necessidades presentes sem comprometer futuras gerações\n- Conferências: Rio-92 (Eco-92), Rio+20, COP (acordos climáticos)\n- Recursos renováveis vs. não-renováveis",
        examples: "Desmatamento da Amazônia: queimadas para agropecuária liberam CO₂, reduzem biodiversidade, afetam regime de chuvas. Relaciona-se com aquecimento global e perda de serviços ecossistêmicos.",
        tips: "DICA ENEM: Relacione problemas ambientais com atividades econômicas. Amazônia = pecuária extensiva. Cerrado = agronegócio (soja). Mata Atlântica = urbanização costeira. Sempre cite CAUSAS e CONSEQUÊNCIAS.",
        videoLinks: "Videoaulas: 'Climas do Brasil - Geografia Ativa' e 'Biomas Brasileiros - Descomplica' e 'Questões Ambientais - Brasil Escola'"
      },
      {
        title: "Geografia Humana e Econômica",
        content: "URBANIZAÇÃO:\n- Brasil: intensificação pós-1950 (êxodo rural, industrialização)\n- Problemas urbanos: favelização, déficit habitacional, violência, mobilidade, saneamento básico\n- Hierarquia urbana: metrópoles, cidades regionais, locais\n- Conurbação, megalópole, região metropolitana\n\nINDUSTRIALIZAÇÃÇÃO:\n- Modelo brasileiro: substituição de importações (Era Vargas, JK)\n- Concentração industrial: Sudeste (desconcentração recente)\n- Revolução Industrial: 1ª (vapor), 2ª (eletricidade), 3ª (informática), 4ª (automação/IA)\n\nAGROPECUÁRIA:\n- Agronegócio vs. Agricultura familiar\n- Modernização: mecanização, transgênicos, agrotóxicos\n- Reforma agrária, MST, conflitos fundiários\n- Brasil: grande exportador (soja, carne, café, açúcar)\n\nGLOBALIZAÇÃO:\n- Integração econômica, cultural, tecnológica\n- Multinacionais, divisão internacional do trabalho\n- Blocos econômicos: UE, Mercosul, BRICS, USMCA\n- Desigualdade global: Norte desenvolvido x Sul subdesenvolvido\n\nGEOPOLÍTICA:\n- Guerra Fria: capitalismo x socialismo, OTAN x Pacto de Varsóvia\n- Ordem multipolar atual: EUA, China, Rússia, UE\n- Conflitos: Oriente Médio (petróleo, religião), África (recursos naturais)\n- Terrorismo, refugiados, xenofobia",
        examples: "Globalização: Apple projeta nos EUA, fabrica na China (mão de obra barata), vende mundialmente. Isso exemplifica a divisão internacional do trabalho e interdependência econômica.",
        tips: "DICA ENEM: Urbanização brasileira = rápida e desigual. Relacione com industrialização (pull factor) e mecanização rural (push factor). Blocos econômicos visam livre comércio entre membros.",
        videoLinks: "Videoaulas: 'Urbanização Brasileira - Geografia Ativa' e 'Globalização - Descomplica' e 'Geopolítica Mundial - Brasil Escola'"
      },
      {
        title: "Cartografia",
        content: "COORDENADAS GEOGRÁFICAS:\n- Latitude: 0° (Equador) a 90° (polos), N ou S\n- Longitude: 0° (Greenwich) a 180°, E ou W\n- Paralelos principais: Trópicos (23°27'), Círculos Polares (66°33')\n- Meridianos: definem fusos horários\n\nFUSOS HORÁRIOS:\n- Terra gira 360° em 24h → 15°/hora\n- Brasil: 4 fusos (desde 2008, 3 fusos oficiais após mudança no Acre)\n- Linha Internacional da Data: 180° (troca de dia)\n- Horário de verão (foi abolido no Brasil em 2019)\n\nESCALAS:\n- Numérica: 1:100.000 (1 cm no mapa = 100.000 cm = 1 km no real)\n- Gráfica: representação visual da escala\n- Escala grande: mais detalhes, área pequena (1:1.000)\n- Escala pequena: menos detalhes, área grande (1:1.000.000)\n\nPROJEÇÕES CARTOGRÁFICAS:\n- Cilíndricas: Mercator (distorce polos, eurocêntrica)\n- Cônicas: Lambert (média latitudes)\n- Azimutais/Planas: polar (útil para aviação)\n- Peters: equivalente, países reais proporções, mas distorce formas\n- Robinson: compromisso entre área e forma\n\nINTERPRETAÇÃO DE MAPAS:\n- Legenda, escala, orientação (Rosa dos Ventos)\n- Mapas temáticos: político, físico, climático, econômico\n- Curvas de nível: relevo (linhas próximas = declive acentuado)",
        formulas: "Fuso horário: diferença = (long₂ - long₁) / 15°\nEscala: E = d/D (mapa/real)\nDistância real: D = d / E",
        examples: "Se no mapa (escala 1:50.000) a distância entre duas cidades é 4 cm:\nDistância real = 4 cm × 50.000 = 200.000 cm = 2 km",
        tips: "DICA ENEM: Mercator (distorce tamanho, mantém forma) - útil navegação. Peters (mantém tamanho, distorce forma) - crítica eurocêntrica. Escala GRANDE = mais detalhes. Escala PEQUENA = menos detalhes.",
        videoLinks: "Videoaulas: 'Cartografia - Geografia Ativa' e 'Projeções Cartográficas - Descomplica' e 'Escalas - Brasil Escola'"
      }
    ]
  },
  {
    subject: "Ciências da Natureza",
    area: "Física",
    topics: [
      {
        title: "Mecânica",
        content: "CINEMÁTICA (estudo do movimento sem considerar forças):\n\nMRU (Movimento Retilíneo Uniforme): velocidade constante\n- S = S₀ + vt (posição = inicial + velocidade×tempo)\n- v = ΔS/Δt\n\nMRUV (Movimento Retilíneo Uniformemente Variado): aceleração constante\n- v = v₀ + at\n- S = S₀ + v₀t + at²/2\n- v² = v₀² + 2aΔS (Torricelli)\n- Queda livre: a = g ≈ 10 m/s²\n\nDINÂMICA (Leis de Newton):\n\n1ª Lei (Inércia): corpo em repouso ou MRU permanece assim se força resultante = 0.\n\n2ª Lei (F = ma): força resultante = massa × aceleração. Peso: P = mg.\n\n3ª Lei (Ação e Reação): toda ação tem reação igual e oposta (em corpos diferentes).\n\nTRABALHO E ENERGIA:\n- Trabalho: W = F × d × cos(θ)\n- Energia Cinética: Ec = mv²/2\n- Energia Potencial Gravitacional: Epg = mgh\n- Energia Potencial Elástica: Epe = kx²/2\n- Conservação: Em + Ep = constante (sem atrito)\n- Potência: P = W/t ou P = F×v",
        formulas: "MRU: S = S₀ + vt\nMRUV: v = v₀ + at; S = S₀ + v₀t + at²/2; v² = v₀² + 2aΔS\n2ª Lei Newton: F = ma\nTrabalho: W = F×d×cos(θ)\nEnergia Cinética: Ec = mv²/2\nPotencial Gravitacional: Epg = mgh\nPotência: P = W/t",
        examples: "Carro freando (MRUV): v₀=30m/s, v=0, a=-5m/s². Distância até parar?\nv² = v₀² + 2aΔS → 0 = 900 - 10ΔS → ΔS = 90m",
        tips: "DICA ENEM: Em queda livre, use g=10m/s². Na conservação de energia, energia mecânica inicial = final (se não há atrito). Trabalho de força contrária ao movimento é NEGATIVO.",
        videoLinks: "Videoaulas: 'Cinemática - Física Total' e 'Leis de Newton - Me Salva!' e 'Energia - Professor Boaro'"
      },
      {
        title: "Eletromagnetismo",
        content: "ELETROSTÁTICA:\n- Carga elétrica: prótons (+), elétrons (-)\n- Lei de Coulomb: F = k × (q₁×q₂)/d² (k = 9×10⁹ N·m²/C²)\n- Campo elétrico: E = F/q ou E = k×Q/d²\n- Potencial elétrico: V = k×Q/d\n- Trabalho: W = q×ΔV\n\nELETRODINÂMICA:\n- Corrente elétrica: i = Q/t (Ampère)\n- Resistência: R = ρL/A (Lei de Ohm: V = R×i)\n- Potência: P = V×i = R×i² = V²/R\n- Energia: E = P×t\n\nCIRCUITOS:\n- Série: Req = R₁ + R₂ + ..., mesma corrente\n- Paralelo: 1/Req = 1/R₁ + 1/R₂ + ..., mesma voltagem\n\nMAGNETISMO:\n- Força magnética em fio: F = B×i×L×sen(θ)\n- Força em carga: F = q×v×B×sen(θ)\n- Indução de Faraday: fem = -ΔΦ/Δt\n- Transformadores: V₁/V₂ = N₁/N₂\n\nONDAS ELETROMAGNÉTICAS:\n- c = λ×f (velocidade luz = 3×10⁸ m/s)\n- Espectro: rádio, micro-ondas, infravermelho, visível, UV, raios-X, gama",
        formulas: "Lei de Coulomb: F = k(q₁q₂)/d²\nLei de Ohm: V = Ri\nPotência: P = Vi = Ri²\nSérie: Req = ΣR\nParalelo: 1/Req = Σ(1/R)\nIndução: fem = -ΔΦ/Δt\nOnda: c = λf",
        examples: "Chuveiro 5000W em 220V consome qual corrente?\nP = Vi → 5000 = 220×i → i ≈ 22,7 A",
        tips: "DICA ENEM: Em circuito série, corrente é igual em todos. Em paralelo, voltagem é igual. Potência = consumo de energia. Resistores em série: soma direta. Em paralelo: inverte, soma, inverte.",
        videoLinks: "Videoaulas: 'Eletrostática - Física Total' e 'Circuitos Elétricos - Me Salva!' e 'Eletromagnetismo - Professor Boaro'"
      }
    ]
  },
  {
    subject: "Ciências da Natureza",
    area: "Química",
    topics: [
      {
        title: "Química Geral e Inorgânica",
        content: "ESTRUTURA ATÔMICA:\n- Prótons (p+), nêutrons (n), elétrons (e-)\n- Número atômico Z = prótons\n- Número de massa A = p + n\n- Distribuição eletrônica: 1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰...\n- Camadas: K(2), L(8), M(18), N(32)\n\nTABELA PERIÓDICA:\n- Períodos (linhas): 7 períodos = 7 camadas\n- Famílias (colunas): 1A a 8A (18 grupos)\n- Metais, não-metais, semimetais, gases nobres\n- Propriedades periódicas: raio atômico, energia de ionização, eletronegatividade\n\nLIGAÇÕES QUÍMICAS:\n- Iônica: metal + não-metal, transferência elétrons (NaCl)\n- Covalente: não-metal + não-metal, compartilhamento (H₂O, CO₂)\n- Metálica: metal + metal, 'mar' de elétrons (Fe, Cu)\n\nFUNÇÕES INORGÂNICAS:\n- Ácidos: HCl, H₂SO₄, HNO₃ (pH < 7, liberam H⁺)\n- Bases: NaOH, Ca(OH)₂ (pH > 7, liberam OH⁻)\n- Sais: NaCl, CaCO₃ (ácido + base)\n- Óxidos: CO₂, H₂O, Fe₂O₃ (elemento + oxigênio)",
        examples: "H₂SO₄ (ácido sulfúrico): 2 H ionizáveis → DIÁCIDO. Forte (ioniza totalmente). Usado em baterias de carro.\n\nNaCl: Na perde 1e⁻ → Na⁺, Cl ganha 1e⁻ → Cl⁻. Ligação IÔNICA.",
        tips: "DICA ENEM: Eletronegatividade cresce → para cima e direita (F é o mais). Raio atômico cresce ← para baixo e esquerda. Força ácida: HI > HBr > HCl > HF (exceto HF, hidrácidos com I mais forte).",
        videoLinks: "Videoaulas: 'Distribuição Eletrônica - Química com Prof. Paulo Valim' e 'Tabela Periódica - QG do Enem' e 'Ligações Químicas - Descomplica'"
      },
      {
        title: "Físico-Química",
        content: "SOLUÇÕES:\n- Concentração comum: C = m/V (g/L)\n- Concentração molar: M = n/V (mol/L onde n = m/MM)\n- Título: τ = m₁/m (soluto/solução)\n- Diluição: C₁V₁ = C₂V₂\n\nTERMOQUÍMICA:\n- Reação exotérmica: libera calor (ΔH < 0). Ex: combustão\n- Reação endotérmica: absorve calor (ΔH > 0). Ex: fotossíntese\n- Lei de Hess: ΔH total = soma ΔH etapas\n\nCINÉTICA QUÍMICA:\n- Velocidade: v = Δconcentração / Δtempo\n- Fatores: temperatura ↑, concentração ↑, superfície contato ↑, catalisador → velocidade ↑\n- Energia de ativação: mínima para reação ocorrer\n\nEQUILÍBRIO QUÍMICO:\n- aA + bB ⇌ cC + dD\n- Kc = [C]ᶜ[D]ᵈ / [A]ᵃ[B]ᵇ\n- Le Chatelier: sistema desloca equilíbrio para compensar perturbação\n- pH = -log[H⁺], pOH = -log[OH⁻], pH + pOH = 14\n\nELETROQUÍMICA:\n- Pilha (espontânea): oxida ânodo, reduz cátodo\n- Eletrólise (não espontânea): inverte processo, precisa energia\n- Nox: variação indica redox (oxida perde e⁻, reduz ganha e⁻)",
        formulas: "Molaridade: M = n/V = m/(MM×V)\nDiluição: C₁V₁ = C₂V₂\nKc = [produtos]/[reagentes]\npH = -log[H⁺]\npH + pOH = 14",
        examples: "Diluir 100mL de solução 2M para 0,5M:\nC₁V₁ = C₂V₂ → 2×100 = 0,5×V₂ → V₂ = 400mL\nAdicionar 300mL de água.",
        tips: "DICA ENEM: Le Chatelier: aumentar reagente → desloca para produtos. Aumentar temperatura em exotérmica → desloca para reagentes (absorve calor). pH < 7 ácido, = 7 neutro, > 7 básico.",
        videoLinks: "Videoaulas: 'Soluções - QG do Enem' e 'Termoquímica - Química Simples' e 'Equilíbrio Químico - Descomplica'"
      },
      {
        title: "Química Orgânica",
        content: "HIDROCARBONETOS (só C e H):\n- Alcanos: ligação simples, CₙH₂ₙ₊₂ (metano CH₄)\n- Alcenos: 1 dupla, CₙH₂ₙ (eteno C₂H₄)\n- Alcinos: 1 tripla, CₙH₂ₙ₋₂ (etino C₂H₂)\n- Aromáticos: anel benzênico (C₆H₆)\n\nFUNÇÕES OXIGENADAS:\n- Álcool: R-OH (etanol C₂H₅OH)\n- Aldeído: R-CHO (formol HCHO)\n- Cetona: R-CO-R' (acetona CH₃COCH₃)\n- Ácido carboxílico: R-COOH (ácido acético CH₃COOH)\n- Éster: R-COO-R' (acetato de etila)\n- Éter: R-O-R' (éter comum)\n\nFUNÇÕES NITROGENADAS:\n- Amina: R-NH₂ (anilina)\n- Amida: R-CO-NH₂ (ureia)\n\nISOMERIA:\n- Plana: cadeia, posição, função, metameria\n- Espacial: geométrica (cis-trans), óptica (assimétrico)\n\nREAÇÕES ORGÂNICAS:\n- Combustão: composto + O₂ → CO₂ + H₂O\n- Substituição: em alcanos (troca H por halogênio)\n- Adição: em alcenos/alcinos (quebra ligação dupla/tripla)\n- Eliminação: forma ligação dupla (álcool → alceno)\n- Esterificação: ácido + álcool → éster + água\n- Saponificação: éster + base → sabão + glicerol\n- Polimerização: monômeros → polímero (plásticos)",
        examples: "Etanol (C₂H₅OH): álcool, combustível. Combustão completa:\nC₂H₅OH + 3O₂ → 2CO₂ + 3H₂O + energia\n\nÉster (banana): ácido butanoico + etanol → butanoato de etila + H₂O",
        tips: "DICA ENEM: Nomenclatura orgânica: PREFIXO (n° carbonos: met-1, et-2, prop-3, but-4) + INFIXO (ligação: an-simples, en-dupla, in-tripla) + SUFIXO (função: o-hidrocarboneto, ol-álcool, al-aldeído, ona-cetona).",
        videoLinks: "Videoaulas: 'Funções Orgânicas - Química Simples' e 'Isomeria - QG do Enem' e 'Reações Orgânicas - Descomplica'"
      }
    ]
  },
  {
    subject: "Ciências da Natureza",
    area: "Biologia",
    topics: [
      {
        title: "Citologia e Bioquímica",
        content: "CÉLULAS:\n- Procarióticas: sem núcleo (bactérias, cianobactérias)\n- Eucarióticas: com núcleo (animais, plantas, fungos, protistas)\n\nORGANELAS:\n- Mitocôndria: respiração celular, produz ATP (\"usina\")\n- Cloroplasto: fotossíntese (só vegetal)\n- Retículo endoplasmático: liso (lipídios), rugoso (proteínas, tem ribossomos)\n- Complexo de Golgi: empacota e secreta substâncias\n- Lisossomo: digestão intracelular (enzimas)\n- Ribossomos: síntese proteica\n- Centríolos: divisão celular (ausente em vegetais superiores)\n\nMEMBRANA PLASMÁTICA:\n- Mosaico fluido: fosfolipídios + proteínas\n- Transporte passivo: difusão, osmose (sem gasto ATP)\n- Transporte ativo: bomba Na⁺/K⁺ (com ATP)\n- Endocitose: fagocitose (sólido), pinocitose (líquido)\n- Exocitose: eliminação\n\nMETABOLISMO:\n- Fotossíntese: 6CO₂ + 6H₂O + luz → C₆H₁₂O₆ + 6O₂ (cloroplasto)\n  Fase clara (tilacóides) + Fase escura (estroma)\n- Respiração aeróbica: C₆H₁₂O₆ + 6O₂ → 6CO₂ + 6H₂O + ATP (mitocôndria)\n  Glicólise + Ciclo de Krebs + Cadeia respiratória = ~38 ATP\n- Fermentação: glicose → ácido lático ou etanol + CO₂ (2 ATP, sem O₂)",
        examples: "Hemácia em solução hipertônica (mais concentrada): água SAI da célula → murcha (crenação).\nHemácia em hipotônica: água ENTRA → incha (hemólise).\nIsotônica: equilíbrio.",
        tips: "DICA ENEM: Fotossíntese e respiração são INVERSAS. Fotossíntese produz glicose e O₂, respiração consome. Mitocôndria = energia (ATP). Cloroplasto = alimento (glicose). Lisossomo = digestão.",
        videoLinks: "Videoaulas: 'Citologia - Biologia Total' e 'Metabolismo Energético - Descomplica' e 'Membrana Plasmática - Prof. Samuel Cunha'"
      },
      {
        title: "Genética",
        content: "1ª LEI DE MENDEL (Segregação):\n- Cada característica é determinada por 2 alelos (um de cada genitor)\n- Na formação dos gametas, os alelos se separam\n- Dominante (A) > Recessivo (a)\n- Genótipo: AA (homozigoto dom), Aa (heterozigoto), aa (homozigoto rec)\n- Fenótipo: expressão visível\n- Cruzamento: Aa × Aa → ¼ AA : ½ Aa : ¼ aa (3:1 fenótipo)\n\n2ª LEI DE MENDEL (Segregação Independente):\n- Genes de características diferentes segregam independentemente\n- AaBb × AaBb → 9:3:3:1 (9 A_B_ : 3 A_bb : 3 aaB_ : 1 aabb)\n\nVARIAÇÕES:\n- Codominância: ambos se expressam (tipo sang. AB)\n- Herança quantitativa: poligênica (altura, cor pele)\n- Ligada ao sexo: gene no X (hemofilia, daltonismo)\n- Letal: genótipo causa morte (amarelo camundongo)\n\nBIOLOGIA MOLECULAR:\n- DNA: dupla hélice, bases A-T, C-G, duplicação semiconservativa\n- RNA: fita simples, A-U, C-G, tipos: RNAm, RNAt, RNAr\n- Transcrição: DNA → RNAm (núcleo)\n- Tradução: RNAm → proteína (ribossomo)\n- Código genético: 64 códons (61 aminoácidos + 3 stop)\n\nBIOTECNOLOGIA:\n- Transgênicos: OGM, gene de outra espécie\n- Clonagem: reprodução assexuada (Dolly)\n- Projeto Genoma, terapia gênica, vacinas",
        examples: "Casal Aa × Aa (A = normal, a = albino):\n¼ AA (normal) + ½ Aa (normal) + ¼ aa (albino) = 3:1\nProbabilidade filho albino: 25%\n\nDaltonismo (Xᵈ): mulher XᵈXᵈ × homem XᴰY → filhas XᴰXᵈ (portadoras), filhos XᵈY (daltônicos)",
        tips: "DICA ENEM: Quadro de Punnett facilita! Lembre: heterozigotos (Aa) não manifestam característica recessiva, mas TRANSMITEM. Herança ligada ao X: homens afetados mais (XY, só 1 X).",
        videoLinks: "Videoaulas: '1ª Lei de Mendel - Biologia Total' e '2ª Lei de Mendel - Prof. Samuel Cunha' e 'Biologia Molecular - Descomplica'"
      },
      {
        title: "Ecologia",
        content: "CONCEITOS:\n- População: indivíduos mesma espécie\n- Comunidade: populações diferentes\n- Ecossistema: comunidade + fatores abióticos\n- Biosfera: todos ecossistemas Terra\n- Habitat: onde vive\n- Nicho ecológico: função, \"profissão\"\n\nCADEIAS E TEIAS ALIMENTARES:\n- Produtores: fotossintetizantes (plantas, algas)\n- Consumidores: herbívoros (1°), carnívoros (2°, 3°...)\n- Decompositores: bactérias, fungos (reciclam matéria)\n- Pirâmides: números, biomassa, energia (sempre ↓)\n\nRELAÇÕES ECOLÓGICAS:\nIntraespecíficas (mesma espécie):\n- Cooperação (sociedade: abelhas, formiga)\n- Competição (território, alimento)\n\nInterespecíficas (espécies diferentes):\n- Mutualismo: +/+ obrigatório (líquen)\n- Protocooperação: +/+ facultativo (pássaro/boi)\n- Comensalismo: +/0 (tubarão/rêmora)\n- Parasitismo: +/- (carrapato/cão)\n- Predação: +/- (leão/zebra)\n- Competição: -/- (mesmo nicho)\n\nCICLOS BIOGEOQUÍMICOS:\n- Carbono: fotossíntese ↔ respiração, combustão\n- Nitrogênio: fixação (bactérias) → aminoácidos → decomposição\n- Água: evaporação → condensação → precipitação\n\nPROBLEMAS AMBIENTAIS:\n- Efeito estufa: CO₂, CH₄ → aquecimento\n- Chuva ácida: SO₂, NOₓ → pH baixo\n- Eutrofização: excesso nutrientes → algas → mortandade\n- Magnificação trófica: agrotóxicos acumulam (↑ trófico)",
        examples: "Cadeia: CAPIM → GAFANHOTO → SAPO → COBRA → GAVIÃO\n(produtor → 1° cons. → 2° cons. → 3° cons. → 4° cons.)\n\nEutrofização: esgoto em rio → nutrientes → proliferação algas → bloqueiam luz → plantas morrem → bactérias consomem O₂ → peixes morrem.",
        tips: "DICA ENEM: Em pirâmide energética, energia SEMPRE diminui (10% passa nível seguinte). Relacione problemas ambientais: efeito estufa (queimadas, combustíveis), chuva ácida (indústrias, carros).",
        videoLinks: "Videoaulas: 'Cadeias Alimentares - Biologia Total' e 'Relações Ecológicas - Prof. Jubilut' e 'Ciclos Biogeoquímicos - Descomplica'"
      }
    ]
  }
];

export const getFullSynopsis = () => {
  return enemSynopsis;
};

export const getSynopsisBySubject = (subject: string) => {
  return enemSynopsis.filter(s => s.subject === subject);
};
